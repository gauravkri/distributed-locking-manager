package com.grv.distributed_locking_manager.serialno;

public interface SerialNoGenerator {

    String getNextSerialNo();
}
