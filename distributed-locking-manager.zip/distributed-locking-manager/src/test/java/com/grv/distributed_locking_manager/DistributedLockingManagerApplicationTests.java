package com.grv.distributed_locking_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributedLockingManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
